let turno = 'cruz';
function permitirSoltar(event) {
    event.preventDefault();
}
function arrastrar(event) {
    event.dataTransfer.setData("text", event.target.id);
}
function soltar(event) {
    event.preventDefault();
    if (event.target.classList.contains("caja") && event.target.children.length === 0) {
        const idElemento = event.dataTransfer.getData("text");
        const ficha = document.getElementById(idElemento);
        if ((turno === 'cruz' && ficha.classList.contains('cruz')) ||
            (turno === 'circulo' && ficha.classList.contains('circulo'))) {
            event.target.appendChild(ficha);
            verificarGanador();
            cambiarTurno();
        }
    }
}
function cambiarTurno() {
    turno = (turno === 'cruz') ? 'circulo' : 'cruz';
    document.getElementById("turnoJugador").innerText = `Turno del jugador: ${turno === 'cruz' ? 'X' : 'O'}`;
}
function verificarGanador() {
    const tablero = Array.from(document.querySelectorAll('.tablero .caja'));
    const combinacionesGanadoras = [
        [0,1,2], [3,4,5], [6,7,8],
        [0,3,6], [1,4,7], [2,5,8],
        [0,4,8], [2,4,6]
    ];
    for (let combinacion of combinacionesGanadoras) {
        const [a, b, c] = combinacion;
        const fichaA = tablero[a].children[0];
        const fichaB = tablero[b].children[0];
        const fichaC = tablero[c].children[0];
        if (fichaA && fichaB && fichaC) {
            if (fichaA.className === fichaB.className && fichaA.className === fichaC.className) {
                const ganador = fichaA.classList.contains('cruz') ? 'X' : 'O';
                document.getElementById("turnoJugador").innerText = `¡Ganador: ${ganador}!`;
                desactivarArrastre();
                return;
            }
        }
    }
    const tableroLleno = tablero.every(caja => caja.children.length > 0);
    if (tableroLleno) {
        document.getElementById("turnoJugador").innerText = "¡Empate!";
        desactivarArrastre();
    }
}
function desactivarArrastre() {
    document.querySelectorAll('.cruz, .circulo').forEach(el => {
        el.setAttribute('draggable', false);
    });
    document.querySelectorAll('.caja').forEach(casilla => {
        casilla.removeAttribute('ondrop');
        casilla.removeAttribute('ondragover');
    });
}
document.querySelectorAll('.cruz, .circulo').forEach(el => {
    el.setAttribute('draggable', true);
    el.addEventListener('dragstart', arrastrar);
});
