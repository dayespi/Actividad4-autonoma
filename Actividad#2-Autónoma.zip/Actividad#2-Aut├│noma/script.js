let display = document.getElementById('display');

function appendValue(value) {
  display.value += value;
}

function clearDisplay() {
  document.getElementById('display').value = '';
  document.getElementById('result').innerText = '';
}


function calculate() {
  try {
    const operation = document.getElementById('display').value;
    const result = eval(operation);
    document.getElementById('result').innerText = '= ' + result;
  } catch {
    document.getElementById('result').innerText = 'Error';
  }
}

